﻿    using Microsoft.Xna.Framework;
    using Microsoft.Xna.Framework.Graphics;
    using Microsoft.Xna.Framework.Input;
    using Microsoft.Xna.Framework.Media;
    using Microsoft.Xna.Framework.Audio ;
    using Microsoft.Xna.Framework.Content;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Diagnostics;
    using System.Linq;     


namespace GalaxyWing2
/// <summary>
/// This is the main type for your game.
/// </summary>
{

    enum Dir { Down, Up, Left, Right }
       
    public class Game1 : Game
        {

        // ---------------------------------------------------------- VARIABLES, OBJECTS AND DATATYPES ----------------------------------------------------------

            GraphicsDeviceManager graphics;
            SpriteBatch spriteBatch;
            Texture2D screen01, screen02, screen03, screen04; //This will be the background
            Texture2D player_sprite; //Assigns a Texture2D for the player character 
            Texture2D gold_player_Sprite; //Assigns a Texture2D for the super secret golden player character 
            Texture2D laser1_sprite; //Assigns a Texture2D for the players projectile 
            Texture2D hunter_sprite; //Assigns a Texture2D for the Hunter enemy 
            Texture2D dasher_sprite;
            Texture2D ts_effect;
            Texture2D extraLife;
            Texture2D asteroid_sprite;
            Texture2D iFrames;
            SpriteFont gFont;
            SpriteFont eFont;

        //screen parameters

            Rectangle border;
            int screenWidth;
            int screenHeight;
         
            public enum GameState { MainMenu, MainGame, GameOver, Paused } //Here we have created different states for our game using GameState
            public GameState gamestate = GameState.MainMenu;// Sets the default gamestate that shows when the game loads
            KeyboardState ks = Keyboard.GetState();
            player player = new player(); // lets me create a new instance of the player
            Asteroid aster = new Asteroid();
            Controller gamecontroller = new Controller();
            
            
       

        // ---------------------------------------------------------- IN_GAME_INFO ----------------------------------------------------------
        
        public float Time = 0; //Used to set the timer
        public int timeIncrement; //Used in combination with gametime in order to allow it to incrementally increase
        public float totalScore = 0; //Used to set the score value to 0
        public Stopwatch totalTime;
        public bool tStop;
        public int lives = 3; //How many lives the player has at the start of the game
        public bool tuto = true; // affects the visibility of the tutorial
        public bool sheild = false;

       public Game1()
            
            {
                graphics = new GraphicsDeviceManager(this);
                graphics.HardwareModeSwitch = false;

                Content.RootDirectory = "Content";

                graphics.PreferredBackBufferWidth = 1200;
                graphics.PreferredBackBufferHeight = 720;

            }
                              
            protected override void Initialize()
            {
            IsMouseVisible = true; //Allows us to see the mouse on the main menu


                base.Initialize();
            }


            protected override void LoadContent()
            {
                // Create a new SpriteBatch, which is usually used to draw textures.
                spriteBatch = new SpriteBatch(GraphicsDevice);


               //these lines of code load in all the textures we need
                screen01 = Content.Load<Texture2D>("mainmenu"); //loads in the title screen 
                screen02 = Content.Load<Texture2D>("bg2"); //loads in the main games background
                screen03 = Content.Load<Texture2D>("Pause"); //loads in the pause screen background
                screen04 = Content.Load<Texture2D>("GameOver"); //loads in the game over screens background
                gFont = Content.Load<SpriteFont>("fonts/gFont"); //loads in the font used for in game text and messages
                eFont = Content.Load<SpriteFont>("fonts/eFont"); //loads in the font used for the game over text 
                ts_effect = Content.Load<Texture2D>("timeStopEffect"); //loads in the time stop effect 



                player_sprite = Content.Load<Texture2D>("ship3"); //Loads in the player
                iFrames = Content.Load<Texture2D>("iFrames"); //Loads in the outline of the player so they know where they are when the game is paused
                dasher_sprite = Content.Load<Texture2D>("Kamikaze"); //Loads in the Kamikaze enemy
                hunter_sprite = Content.Load<Texture2D>("badguy"); //Loads in the hunter enemy
                asteroid_sprite = Content.Load<Texture2D>("Asteroid"); //Loads in the asteroid
                extraLife = Content.Load<Texture2D>("extraLife"); //Loads in the extra life                                             
                gold_player_Sprite = Content.Load<Texture2D>("PC-3 Spaceship"); //Loads in the golden player sprite
                laser1_sprite = Content.Load<Texture2D>("laser1"); //Loads in the laser sprite  
            }

             protected override void UnloadContent()// TODO: Unload any non ContentManager content here

             {
                

             }
        
        #region update Method
        // ---------------------------------------------------------- UPDATE_METHOD ----------------------------------------------------------


        protected override void Update(GameTime gameTime) // Update Method
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            ks = Keyboard.GetState();

            switch (gamestate)
            {
     // ---------------------------------------------------------- MAIN MENU GAMESTATE ----------------------------------------------------------
                #region GameState MainMenu
                case GameState.MainMenu:
                    
                if (ks.IsKeyDown(Keys.Enter)) //When the player presses enter the game starts
                    {
                        gamestate = GameState.MainGame;
                }

                    if (gamestate == GameState.MainMenu) //Gamestate - Game Over
                    {
                        totalScore = 0;
                        lives = 3;
                    }

                    break;
                #endregion
     // ---------------------------------------------------------- MAIN GAME GAMESTATE ----------------------------------------------------------
                #region GameState MainGame

                case GameState.MainGame:

                    if (ks.IsKeyDown(Keys.Q)) //When the player presses Q it activates their sheild
                    {
                        sheild = true;
                    }

                    if (ks.IsKeyUp(Keys.Q)) //When the player presses Q it activates their sheild
                    {
                        sheild = false;
                    }

                    if (ks.IsKeyDown(Keys.P)) //When the player presses the P key it pauses the game
                    {
                        gamestate = GameState.Paused;
                    }

                    if (ks.IsKeyDown(Keys.LeftShift)) //When the player holds left Shift  time stop is activated
                    {
                        tStop = true;

                    }

                    if (ks.IsKeyUp(Keys.LeftShift))
                    {
                        tStop = false;

                    }


                    if (tuto == false)                     
                        if (tStop == false) //When time moves the timer and score increase unless the tutorial is active
                        {

                            Time += (float)gameTime.ElapsedGameTime.TotalSeconds;
                            totalScore += (float)gameTime.ElapsedGameTime.TotalSeconds * 10;

                        }

                        if (tStop == true) //When time has been stopped so does the timer and score 
                        {
                            Time += (float)gameTime.ElapsedGameTime.TotalSeconds;
                            totalScore += 0;

                        }
                    #region .Updates(gameTime)   
                        //allows the game to update the code 
                    player.playerUpdate(gameTime);

                    aster.asterUpdate(gameTime);

                    gamecontroller.conUpdate(gameTime);

                    
                    #endregion

                    #region spawing and  hit detection (hunters and dashers)

                    for (int i = 0; i < gamecontroller.hunters.Count; i++)
                    {
                        gamecontroller.hunters[i].hunterUpdate(gameTime);
                        
                    }

                    for (int i = 0; i < gamecontroller.dashers.Count; i++)
                    {
                        
                        gamecontroller.dashers[i].dasherUpdate(gameTime);
                    }

                    for (int i = 0; i < gamecontroller.hunters.Count; i++)
                    {
                        for (int j = 0; j < Projectile.projectiles.Count; j++)
                        {
                            
                                if (gamecontroller.hunters[i].rect.Intersects(Projectile.projectiles[j].rect))
                            {
                                gamecontroller.hunters.RemoveAt(i);
                                Projectile.projectiles.RemoveAt(j);
                                totalScore = totalScore + 10;
                                break;

                            }
                                                      
                        }
                    }
                                       
                   
                    for (int i = 0; i < gamecontroller.hunters.Count; i++)
                    {
                        {
                            if (sheild == false)
                                if (gamecontroller.hunters[i].rect.Intersects(player.rect))
                            {
                                gamecontroller.hunters.RemoveAt(i);
                                lives--;
                                break;

                            }
                        }
                    }

                    for (int i = 0; i < gamecontroller.hunters.Count; i++)
                    {
                        {
                            if (sheild == true)
                                if (gamecontroller.hunters[i].rect.Intersects(player.rect))
                            {
                                gamecontroller.hunters.RemoveAt(i);
                                    totalScore += 10;
                                break;

                            }
                        }
                    }

                    for (int i = 0; i < gamecontroller.dashers.Count; i++)
                    {
                        {
                            if (sheild == true)
                                if (gamecontroller.dashers[i].rect.Intersects(player.rect))
                            {
                                gamecontroller.dashers.RemoveAt(i);
                                    totalScore += 10;
                                break;

                            }
                        }
                    }

                    for (int i = 0; i < gamecontroller.dashers.Count; i++)
                    {
                        {
                            if (sheild == false)
                                if (gamecontroller.dashers[i].rect.Intersects(player.rect))
                                {
                                    gamecontroller.dashers.RemoveAt(i);
                                    lives--;
                                    break;

                                }
                        }
                    }
                    #endregion
                                        
                    for (int i = 0; i < gamecontroller.dashers.Count; i++)
                    {
                        for (int j = 0; j < Projectile.projectiles.Count; j++)
                        {
                            if (gamecontroller.dashers[i].rect.Intersects(Projectile.projectiles[j].rect))
                            {
                                gamecontroller.dashers.RemoveAt(i);
                                Projectile.projectiles.RemoveAt(j);
                                totalScore = totalScore + 10;
                                break;
                            }

                        }
                    }

                    if (aster.rect.Intersects(player.rect))
                        {

                            lives--;
                            break;

                        }
                    
                   
                    
                    if (lives <= 0) //When the players lives hit 0 then the game ends
                    {
                         gamestate = GameState.GameOver;
                    }

                    if (ks.IsKeyDown(Keys.LeftShift)) //Allows the player to trigger the time stop
                    {
                        tStop = true;
                    }
#region tutorial                               
                    if (tuto == true) // allows the tutorial to appear at the start of the game
                    {
                        tStop = true; //Stops time during the tutorial

                        if (ks.IsKeyDown(Keys.W)) //end the tutorial when the player moves and begins the game
                        {

                            tuto = false;

                            totalScore += 0;
                        }

                        if (ks.IsKeyDown(Keys.A))
                        {

                            tuto = false;

                            totalScore += 0;
                        }

                        if (ks.IsKeyDown(Keys.S))
                        {

                            tuto = false;

                            totalScore += 0;
                        }
                        
                        if (ks.IsKeyDown(Keys.D))
                        {

                            tuto = false;
                            totalScore += 0;
                        }

                        break;

                    }
                    break;
                #endregion
                #endregion
     // ---------------------------------------------------------- GAME OVER GAMESTATE ----------------------------------------------------------
                #region GameState GameOver
                case GameState.GameOver:
                                                          
                    if (ks.IsKeyDown(Keys.Space)) //Gamestate - Game Over
                    {
                        gamestate = GameState.MainMenu;
                    }
           
                    break;
                #endregion
      // ---------------------------------------------------------- PAUSED GAMESTATE ----------------------------------------------------------
                #region GameState Paused
                case GameState.Paused: //Gamestate - Main Menu 
                                        
                    if (ks.IsKeyDown(Keys.Space))

                    {

                        gamestate = GameState.MainGame;
                    }

                    break;
                    #endregion
            }

            base.Update(gameTime);
            }
        #endregion
       
        // ---------------------------------------------------------- DRAW_METHOD ----------------------------------------------------------
        #region draw method

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);
                                                
            spriteBatch.Begin();
            


            switch (gamestate)
            {

                case GameState.MainMenu://MainMenu is screen1
                    spriteBatch.Draw(screen01, new Vector2(0, 0), Color.White);
                    break;
                    
                case GameState.MainGame: //MainGame is Screen2
                  
                    #region screen and screen boundaries
                    spriteBatch.Draw(screen02, new Vector2(0, 0), Color.White);
                    screenWidth = GraphicsDevice.Viewport.Width; //this makes the screenWidth equal to the width of the viewport. Note: while I could've set the value to 1200 manually I dont want to hard code it in as i might change it later
                    screenHeight = GraphicsDevice.Viewport.Height; //this makes the screenHeight equal to the height of the viewport. Note: while I could've set the value to 720 manually I dont want to hard code it in as i might change it later
                    #endregion

                    #region player sprites

                    if (totalScore >= 10000) //If the players total score is greater than 10,000 the the player gets a super secret gold sprite
                    {
                        spriteBatch.Draw(gold_player_Sprite, new Vector2(player.position.X - 50, player.position.Y - 50), Color.White);
                    }

                    if (totalScore <= 10000)
                    {
                        spriteBatch.Draw(player_sprite, new Vector2(player.position.X - 50, player.position.Y - 50), Color.White); //If the players total score is less then 10,000 then the usual player sprite is drawn
                    }

                    if (sheild == true)
                    {
                        spriteBatch.Draw(iFrames, new Vector2(player.position.X - 50, player.position.Y - 50), Color.White); //If the players sheild is up then the players sprite will change 
                    }
                    #endregion

                    // to implement - spriteBatch.Draw(extraLife, new Vector2(exLife.position.X - 32, exLife.position.X - 32), Color.White);

                    #region player info

                    spriteBatch.DrawString(gFont, "Score: " + totalScore.ToString("0.00"), new Vector2(000, 0), Color.White);
                    spriteBatch.DrawString(gFont, "Lives: " + lives.ToString("0.00"), new Vector2(800, 0), Color.White);
                    #endregion
                    #region hunter and dasher spawns

                    if (tuto == false) //Prevents the hunters from spawning when the tutorial is active
                    {
                        for (int i = 0; i < gamecontroller.hunters.Count; i++)// draws the hunters into the game when their number is called
                        {
                            Vector2 tempPos = gamecontroller.hunters[i].position;
                            int tempRadius = gamecontroller.hunters[i].radius;
                            spriteBatch.Draw(hunter_sprite, new Vector2(tempPos.X - tempRadius, tempPos.Y - tempRadius), Color.White);
                        }
                    }

                    if (tuto == false) //Prevents the dashers from spawning when the tutorial is active
                        {
                        for (int i = 0; i < gamecontroller.dashers.Count; i++)// draws the dashers into the game when their number is called
                        {
                            Vector2 tempPos2 = gamecontroller.dashers[i].position;
                            int tempRadius2 = gamecontroller.dashers[i].radius;
                            spriteBatch.Draw(dasher_sprite, new Vector2(tempPos2.X - tempRadius2, tempPos2.Y - tempRadius2), Color.White);

                        }
                    }

                    foreach (Projectile projectile in Projectile.projectiles) //Draws in the players projectile when active
                    {
                        spriteBatch.Draw(laser1_sprite, new Vector2(projectile.Position.X + 5, projectile.Position.Y - 10), Color.White);
                    }
                    #endregion



                    spriteBatch.Draw(asteroid_sprite, new Vector2(aster.position.X, aster.position.Y), Color.White);
                   
                    if (tStop == true) //Draws in the time stop effects when active
                    {
                        spriteBatch.Draw(ts_effect, new Vector2(0, 0), Color.White);
                        spriteBatch.DrawString(eFont, "Time has stopped.", new Vector2(525 - 50, 720 - 50), Color.White);
                    }

                    if (tuto == true) //Draws in the tutorial when active
                    {
                        spriteBatch.DrawString(gFont, "Use WASD to move", new Vector2(player.position.X -50 , player.position.Y - 100), Color.White);
                        spriteBatch.DrawString(gFont, "Use Left Shift to Stop Time and look at your surroundings", new Vector2(player.position.X + 50, player.position.Y -30), Color.White);
                        spriteBatch.DrawString(gFont, "Move to begin your last stand.", new Vector2(player.position.X + 700, player.position.Y -30), Color.White);
                        spriteBatch.DrawString(gFont, "Q to activate your sheild", new Vector2(player.position.X - 50, player.position.Y + 25), Color.White);
                    }



                    break;
                #region GameOver_screens
                case GameState.Paused: //Paused is Screen3
                    spriteBatch.Draw(screen03, new Vector2(0, 0), Color.White);
                    spriteBatch.DrawString(eFont, "Your current score is ...", new Vector2(25, 205), Color.White);
                    spriteBatch.DrawString(eFont, totalScore.ToString("0.00"), new Vector2(25, 255), Color.White);
                    spriteBatch.Draw(iFrames, new Vector2(player.position.X - 50, player.position.Y - 50), Color.White); //If the players total score is less then 10,000 then the usual player sprite is drawn
                    break;

                case GameState.GameOver: //GameOver is Screen4
                    spriteBatch.Draw(screen04, new Vector2(0, 0), Color.White);

                    if (totalScore <= 100)
                    {
                        spriteBatch.DrawString(eFont, "You barely scraped together a measly score of...", new Vector2(265, 300), Color.White);
                        spriteBatch.DrawString(eFont, totalScore.ToString("0.00") + " points", new Vector2(525, 350), Color.White);
                        spriteBatch.DrawString(eFont, "Awwwwww... Don't worry, I'm sure you tried your hardest", new Vector2(225, 400), Color.White);
                        spriteBatch.DrawString(eFont, "Press Space to try again.", new Vector2(400, 550), Color.White);
                    }

                    if (totalScore >= 100)
                        if (totalScore <= 1000)
                        {
                        spriteBatch.DrawString(eFont, "You attained a fairly decent score of...", new Vector2(365, 300), Color.White);
                        spriteBatch.DrawString(eFont, totalScore.ToString("0.00") + " points", new Vector2(525, 350), Color.White);
                        spriteBatch.DrawString(eFont, "Despite your best efforts the didact now rules the galaxy", new Vector2(250, 400), Color.White);
                        spriteBatch.DrawString(eFont, "Press Space to try again.", new Vector2(400, 550), Color.White);
                    }
                                                         
                    if (totalScore >= 1000 )
                    {
                        spriteBatch.DrawString(eFont, "You achived a worthy score of... " , new Vector2(400, 300), Color.White);
                        spriteBatch.DrawString(eFont, totalScore.ToString("0.00") + " points", new Vector2(525, 350), Color.White);
                        spriteBatch.DrawString(eFont, "You made a valiant last stand... giving us a fighting chance", new Vector2(225, 400), Color.White);
                        spriteBatch.DrawString(eFont, "Truly thank you, Godspeed Galaxy Wing!", new Vector2(325, 450), Color.White);
                        spriteBatch.DrawString(eFont, "Press Space to try again.", new Vector2(400, 550), Color.White);

                    }

                   
                    break;
                    #endregion

            }

            spriteBatch.End();
            #endregion
        }
    }

}