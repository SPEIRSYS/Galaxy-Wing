﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Linq;


namespace GalaxyWing2
{
    class Controller
    {

        public List<Hunter> hunters = new List<Hunter>(); //List for the hunter enemy
        public List<Dasher> dashers = new List<Dasher>();//List for the dasher enemy
        public double timer = 2D;
        

        public void conUpdate(GameTime gameTime)
            {
               KeyboardState kState = Keyboard.GetState();

                timer -= gameTime.ElapsedGameTime.TotalSeconds;

               if (timer <= 0) //Allows enemies to spawn wen the timer is equal to or less than 0
                if (kState.IsKeyUp(Keys.LeftShift)) 
                {

                  hunters.Add(new Hunter(250));
                    dashers.Add(new Dasher(100));
                      timer = 2D;
                 }
                                   
        }


        public void exUpdate(GameTime gameTime)
        {
            KeyboardState kState = Keyboard.GetState();

            timer -= gameTime.ElapsedGameTime.TotalSeconds;

            if (timer <= 0) //Allows enemies to spawn wen the timer is equal to or less than 0
                if (kState.IsKeyUp(Keys.LeftShift))
                {
                                      
                    
                    timer = 2D;
                }



        }



    }
} 
 