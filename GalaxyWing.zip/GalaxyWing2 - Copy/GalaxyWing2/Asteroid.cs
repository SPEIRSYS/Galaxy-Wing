﻿using System;
using System.Timers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace GalaxyWing2
{
    class Asteroid
    {
        
        public int speed = 10; // This is the speed of the Asteroid
        public Timer spawnTimer;
        public Vector2 position = new Vector2(-200, 000);
        public Rectangle rect;
        private int radius = 30;
        Random rng = new Random(); //Lets me generate a random number
        bool tStop = false;
              
        public Asteroid()

         {
            if (tStop == false)
           {
                spawnTimer = new Timer(rng.Next(8000, 14000)); // How minimmum / maximum time it takes for a new asteroid to spawn in milliseconds
                spawnTimer.Elapsed += SpawnAster;
                spawnTimer.Start();
            }
                                                         
        }

        public void SpawnAster(object sender, ElapsedEventArgs e)
        {
            
            position.X = rng.Next(1350 - radius, 1500-radius); //Spawn Location   
            position.Y = rng.Next(15 - radius, 720 - radius); //Spawn location

            position.X -= speed;
        }

        public void asterUpdate(GameTime gameTime)

        {

            KeyboardState kState = Keyboard.GetState();


            if (kState.IsKeyUp(Keys.LeftShift)) //Moves the asteroid left unless time has been stopped
            {
                position.X -= speed;
                speed = 10; //Restes the speed of the asteroid when time begins to move
                tStop = false;
                

            }

            if (kState.IsKeyDown(Keys.LeftShift)) //freezes the asteroid in place when time has stopped
            {
                tStop = true;
                speed = 0;
                position.X -= speed;

            }


            rect = new Rectangle((int)position.X, (int)position.Y, radius * 2, radius * 2);
        }

    }

}
    


