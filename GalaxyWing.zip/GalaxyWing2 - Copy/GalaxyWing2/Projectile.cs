﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace GalaxyWing2
{
    class Projectile
    {
        public Vector2 position;
        private int speed = 800;
        private int radius = 15;
        private Dir direction;
      

        public static List<Projectile> projectiles = new List<Projectile>();
        public Rectangle rect;

        public Projectile(Vector2 newPos, Dir newDir)
        {
            newPos = new Vector2(position.X--, position.Y);
            position = newPos;
            direction = newDir;
                       
        }
          
        public Vector2 Position
        {
            get { return position; }
        }

        public int Radius
        {
            get { return radius; }
        }

        public void projUpdate(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            switch (direction)
            {
                case Dir.Right:
                    position.X += speed * dt;
                    break;
            default:
                    break;
            }

            rect = new Rectangle((int)position.X, (int)position.Y, radius * 2, radius * 2);
        }

    }
}
