﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace GalaxyWing2
{
    class Dasher
    {

        public Vector2 position = new Vector2 (1350, 500);
        public int speed; //this is the speed of the hunter enemy (I don't need to assign it a value as that is done at - if (tStop == False) -)
        public int radius = 50;
        public bool tStop = false;
        Random rng = new Random(); //Lets me generate a random number
        public Rectangle rect = new Rectangle(); // This is the hitbox for the dasher enemy

        public Dasher(int newSpeed)
        {
            speed = newSpeed;
        }

       
        public void dasherUpdate(GameTime gameTime)
        {

            KeyboardState kState = Keyboard.GetState();

            
            if (kState.IsKeyUp(Keys.LeftShift)) //Moves the asteroid left unless time has been stopped
            {
                tStop = false;
                float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
                position.X -= speed * dt;
                rect = new Rectangle((int)position.X, (int)position.Y, radius * 2, radius * 2);
            }

            if (kState.IsKeyDown(Keys.LeftShift)) //Moves the asteroid left unless time has been stopped

            {
                tStop = true;
                float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
                position.X -= speed * dt;

            }
                
            if (tStop == true) //Prevents the dasher from moving as its speed will be 0 during stopped time
            {

                speed = 0; 

            }

            if (tStop == false)
            {
                float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
                speed = 850;

            }
          }
       }
     }