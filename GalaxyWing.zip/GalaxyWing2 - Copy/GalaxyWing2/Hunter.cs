﻿using System;
using System.Timers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace GalaxyWing2
{
    class Hunter
    {
        public Vector2 position = new Vector2 (1250, 300);
        public int attackTimer = 100;
        public int speed; //this is the speed of the hunter enemy (I don't need to assign it a value as that is done at - if (tStop == False) -)
        public int radius = 50;
        public bool tStop = false;
        Random rng = new Random(); //Lets me generate a random number
        public Rectangle rect;// This is the hitbox for the Hunter enemy

        public Hunter(int newSpeed)
        {
            speed = newSpeed;
        }
                               
        public void hunterUpdate (GameTime gameTime)
            {

            KeyboardState kState = Keyboard.GetState();
                    

            if (kState.IsKeyUp(Keys.LeftShift)) //Moves the hunter left unless time has been stopped
            {
                tStop = false;
                float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
                position.X -= speed * dt;
                rect = new Rectangle((int)position.X, (int)position.Y, radius * 2, radius * 2);
            }

            if (tStop == false)
            {
                attackTimer --; // How minimmum / maximum time it takes for a new asteroid to spawn in milliseconds
                
            }

            if(attackTimer <= 0)
            {
                //Projectile.projectiles.Add(new Projectile(position));
                attackTimer = 100;
            }

            if (tStop == true) //freezes the enemy when time is stopped
            {

                speed = 0;

            }

            if (tStop == false)
            {
                float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
                speed = 500;

            }
                      

        }
                
    }

}
