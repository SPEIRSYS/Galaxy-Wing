﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System.Timers;

namespace GalaxyWing2
{
    class player
    {
        public float pSpeed = 200; // This is the speed of the player
        public float tSpeed = 100; //This is the speed of the player when time has stopped
        public int radius = 30;
        public Vector2 position = new Vector2(100, 350);
        private Dir direction = Dir.Down;
        private bool isMoving = false;
        private bool tStop = false;
        private KeyboardState kStateOld = Keyboard.GetState();
        public Rectangle rect;
        

        

        public void playerUpdate(GameTime gameTime) // This is a return void as we dont need this method to return anything
        {
            
            KeyboardState kState = Keyboard.GetState();
            float dt = (float)gameTime.ElapsedGameTime.TotalMilliseconds;

            isMoving = false;

            // ---------------------------------------------------------- MOVE RIGHT ----------------------------------------------------------
            #region Move Right

            if (kState.IsKeyDown(Keys.D)) //Moves the Player Right when they arent pressing shift

            {
                direction = Dir.Right;
                isMoving = true;
            }
            if (kState.IsKeyDown(Keys.Space) && kStateOld.IsKeyUp(Keys.Space))
            {
                Projectile.projectiles.Add(new Projectile(position, direction));
            }

            kStateOld = kState;
            #endregion
                       
            // ---------------------------------------------------------- MOVE LEFT ----------------------------------------------------------
            #region Move left

            if (kState.IsKeyDown(Keys.A)) //Moves the Player Left
            {
                direction = Dir.Left;
                isMoving = true;
            }
                        
            kStateOld = kState;
            #endregion

            // ---------------------------------------------------------- MOVE DOWN ----------------------------------------------------------
            #region Move down

            if (kState.IsKeyDown(Keys.S)) //Moves the Player Down

            {
                direction = Dir.Up;
                isMoving = true;
            }

                       kStateOld = kState;
            #endregion

            // ---------------------------------------------------------- MOVE UP ----------------------------------------------------------
            #region Move up

            if (kState.IsKeyDown(Keys.W)) //Moves the Player Up
            {
                direction = Dir.Down;
                isMoving = true;
            }
                        
            #endregion
                       
            // ---------------------------------------------------------- TIME STOP ----------------------------------------------------------
            #region timeStop
            if (kState.IsKeyDown(Keys.LeftShift)) //Prevents the player from moving when theyre pressing left Shift
            {
                tStop = true;

            }

            if (kState.IsKeyUp(Keys.LeftShift)) //Prevents the player from moving when theyre pressing left Shift
            {
                tStop = false;

            }
            kStateOld = kState;
            #endregion

            // ---------------------------------------------------------- MOVEMENT----------------------------------------------------------
            #region movement
            if (isMoving)
                if (tStop == false)
                {

                    switch (direction) // moves the player by speed/dt in their given direction
                    {
                        case Dir.Right:
                            position.X += pSpeed / dt;
                            break;
                        case Dir.Left:
                            position.X -= pSpeed / dt;
                            break;
                        case Dir.Up:
                            position.Y += pSpeed / dt;
                            break;
                        case Dir.Down:
                            position.Y -= pSpeed / dt;
                            break;
                        default:
                            break;
                    }
                    #region screen borders and hit detection
                    if (position.X <= 0 + radius*2)
                    {
                      position.X = 0 + radius*2;
                    }

                    if (position.Y <= 10 + radius * 2)
                    {
                        position.Y = 10 + radius * 2;
                    }

                    if (position.Y <= 10 + radius * 2)
                    {
                        position.Y = 10 + radius * 2;
                    }

                    if (position.Y >= 620 + radius+20 * 2)
                    {
                        position.Y = 620 + radius+20 * 2;
                    }

                    if (position.Y >= 620 + radius + 20 * 2)
                    {
                        position.Y = 620 + radius + 20 * 2;
                    }

                    if (position.X >= 1200 - 30)
                    {
                        position.X = 1200 - 30;
                    }


                    rect = new Rectangle((int)position.X, (int)position.Y, radius * 2, radius * 2);
                    #endregion
                    #endregion
                }
        }
    }
}



      
